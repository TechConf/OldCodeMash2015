#!/bin/sh

# WARNING: This file is created by the Configuration Wizard.
# Any changes to this script may be lost when adding extensions to this configuration.

DOMAIN_HOME="/appl/oracle/middleware/wls/wls12120/user_projects/domains/mydomain"

${DOMAIN_HOME}/bin/startWebLogic.sh $*

